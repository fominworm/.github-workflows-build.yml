package com.taptap.haybot.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.PointF
import android.os.Build
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.annotation.RequiresApi
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.*
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.taptap.haybot.engine.GestureAndCameraController
import com.taptap.haybot.engine.WheatingStateMachine
import com.taptap.haybot.model.BotRuntimeState
import com.taptap.haybot.model.OverlayUiState
import com.taptap.haybot.ui.TapTapOverlayRoot
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.math.roundToInt

class TapTapAccessibilityService : AccessibilityService(),
    LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: ComposeView
    private lateinit var layoutParams: WindowManager.LayoutParams

    private lateinit var botState: BotRuntimeState
    private lateinit var stateMachine: WheatingStateMachine

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val screenshotExecutor = Executors.newSingleThreadExecutor()

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onServiceConnected() {
        super.onServiceConnected()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        botState = BotRuntimeState(this)

        val gestureController = GestureAndCameraController(this)
        stateMachine = WheatingStateMachine(
            state = botState,
            gestures = gestureController,
            pixelReader = { point -> captureSinglePixelColor(point) }
        )

        setupFloatingOverlay()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun setupFloatingOverlay() {
        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 180
            y = 40
        }

        overlayView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@TapTapAccessibilityService)
            setViewTreeViewModelStoreOwner(this@TapTapAccessibilityService)
            setViewTreeSavedStateRegistryOwner(this@TapTapAccessibilityService)

            setContent {
                LaunchedEffect(botState.uiState) {
                    if (botState.uiState == OverlayUiState.CALIBRATION) {
                        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT
                        layoutParams.height = WindowManager.LayoutParams.MATCH_PARENT
                    } else {
                        layoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT
                        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT
                    }
                    windowManager.updateViewLayout(overlayView, layoutParams)
                }

                TapTapOverlayRoot(
                    botState = botState,
                    onStartStopClick = {
                        if (botState.isRunning) stateMachine.stop() else stateMachine.start()
                    },
                    onMoveOverlayWindow = { dx, dy ->
                        if (botState.uiState != OverlayUiState.CALIBRATION) {
                            layoutParams.x += dx.roundToInt()
                            layoutParams.y += dy.roundToInt()
                            windowManager.updateViewLayout(overlayView, layoutParams)
                        }
                    }
                )
            }
        }

        windowManager.addView(overlayView, layoutParams)
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private suspend fun captureSinglePixelColor(point: PointF): Int? =
        suspendCancellableCoroutine { cont ->
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                screenshotExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        val hwBuffer = screenshot.hardwareBuffer
                        val bitmap = Bitmap.wrapHardwareBuffer(hwBuffer, screenshot.colorSpace)
                        val softBitmap = bitmap?.copy(Bitmap.Config.ARGB_8888, false)
                        hwBuffer.close()
                        bitmap?.recycle()

                        val x = point.x.roundToInt().coerceIn(0, (softBitmap?.width ?: 1) - 1)
                        val y = point.y.roundToInt().coerceIn(0, (softBitmap?.height ?: 1) - 1)
                        val color = softBitmap?.getPixel(x, y)
                        softBitmap?.recycle()

                        if (cont.isActive) cont.resume(color)
                    }

                    override fun onFailure(errorCode: Int) {
                        if (cont.isActive) cont.resume(null)
                    }
                }
            )
        }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stateMachine.stop()
    }

    override fun onDestroy() {
        stateMachine.stop()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        if (::overlayView.isInitialized) {
            windowManager.removeView(overlayView)
        }
        super.onDestroy()
    }
}
