package com.taptap.haybot.engine

import android.graphics.Color
import android.graphics.PointF
import android.os.Build
import androidx.annotation.RequiresApi
import com.taptap.haybot.model.BotPhase
import com.taptap.haybot.model.BotRuntimeState
import kotlinx.coroutines.*
import kotlin.math.min

class WheatingStateMachine(
    private val state: BotRuntimeState,
    private val gestures: GestureAndCameraController,
    private val pixelReader: suspend (PointF) -> Int?
) {
    private var engineJob: Job? = null
    private var timersJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    @RequiresApi(Build.VERSION_CODES.O)
    fun start() {
        if (state.isRunning) return
        state.isRunning = true
        state.statusLog = "Запуск цикла TapTap Bot..."
        startBackgroundTimers()

        engineJob = scope.launch {
            while (isActive && state.isRunning) {
                runSingleStep()
                delay(250L)
            }
        }
    }

    fun stop() {
        state.isRunning = false
        state.currentPhase = BotPhase.IDLE
        state.statusLog = "Бот остановлен пользователем"
        engineJob?.cancel()
        timersJob?.cancel()
    }

    private fun startBackgroundTimers() {
        timersJob?.cancel()
        timersJob = scope.launch {
            while (isActive && state.isRunning) {
                delay(1000L)
                state.uptimeSeconds++
                if (state.maturityRemainingSec > 0) state.maturityRemainingSec--
                if (state.adCooldownRemainingSec > 0) state.adCooldownRemainingSec--
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private suspend fun runSingleStep() {
        when (state.currentPhase) {
            BotPhase.IDLE, BotPhase.CHECK_CAPACITY -> {
                state.currentPhase = BotPhase.CHECK_CAPACITY

                if (state.maturityRemainingSec > 0) {
                    if (state.hotSwapEnabled && state.availableStacksToSell > 0) {
                        state.currentPhase = BotPhase.CAMP_ALERT
                    } else {
                        state.currentPhase = BotPhase.WAIT_GROWTH
                    }
                    return
                }

                if (!state.canFullHarvestSafely) {
                    state.statusLog = "Силос полон (${state.siloCurrent}/${state.siloCapacity}). Разгрузка..."
                    state.currentPhase = BotPhase.LOAD_SHOP
                } else {
                    state.currentPhase = BotPhase.HARVEST
                }
            }

            BotPhase.HARVEST -> {
                val batch = state.safeHarvestBatchCount
                if (batch <= 0) {
                    state.statusLog = "Нет места даже для микро-сбора! Идем в киоск"
                    state.currentPhase = BotPhase.LOAD_SHOP
                    return
                }

                state.statusLog = "Сбор поля ($batch грядок)..."
                gestures.executeFieldActionWithDeadStop(
                    anchorField = state.points.anchorField,
                    toolIcon = state.points.toolIcon,
                    fieldEnd = state.points.fieldEnd,
                    deadStopGrass = state.points.deadStopGrass,
                    swipeDurationMs = state.swipeDurationMs,
                    useDeadStop = state.deadStopEnabled
                )

                val gained = batch * 2
                state.siloCurrent = min(state.siloCapacity, state.siloCurrent + gained)
                state.wheatCurrent += gained
                state.saveSettings()

                state.currentPhase = BotPhase.PLANT
            }

            BotPhase.PLANT -> {
                val toPlant = min(state.fieldCount, state.wheatCurrent)
                state.statusLog = "Посев ($toPlant грядок) + Dead-Stop камеры..."

                gestures.executeFieldActionWithDeadStop(
                    anchorField = state.points.anchorField,
                    toolIcon = state.points.toolIcon,
                    fieldEnd = state.points.fieldEnd,
                    deadStopGrass = state.points.deadStopGrass,
                    swipeDurationMs = state.swipeDurationMs,
                    useDeadStop = state.deadStopEnabled
                )

                state.siloCurrent = (state.siloCurrent - toPlant).coerceAtLeast(0)
                state.wheatCurrent = (state.wheatCurrent - toPlant).coerceAtLeast(0)
                state.maturityRemainingSec = 120
                state.saveSettings()

                if (state.availableStacksToSell > 0) {
                    state.currentPhase = BotPhase.LOAD_SHOP
                } else {
                    state.currentPhase = BotPhase.WAIT_GROWTH
                }
            }

            BotPhase.LOAD_SHOP -> {
                state.statusLog = "Открытие киоска и выкладка товара..."
                gestures.tap(state.points.shopRoofAlert, 70L)
                delay(450L)

                collectSoldSlots()

                val stacksToPut = min(state.availableStacksToSell, state.shopTotalSlots)
                if (stacksToPut > 0) {
                    fillShopSlots(
                        count = stacksToPut,
                        placeAdOnLastSlot = (state.adCooldownRemainingSec == 0)
                    )
                }

                delay(250L)
                gestures.tap(state.points.deadStopGrass, 80L)
                delay(300L)

                state.currentPhase = if (state.hotSwapEnabled && state.availableStacksToSell > 0) {
                    BotPhase.CAMP_ALERT
                } else {
                    BotPhase.WAIT_GROWTH
                }
            }

            BotPhase.CAMP_ALERT -> {
                state.statusLog = "Охота на [!]: ждем покупателя (Резерв: ${state.seedReserve})"

                while (state.isRunning && state.maturityRemainingSec > 5 && state.availableStacksToSell > 0) {
                    val pixel = pixelReader(state.points.shopRoofAlert)
                    if (pixel != null && isExclamationAlertColor(pixel)) {
                        state.statusLog = "Замечен знак [!] — вход в HOT-SWAP!"
                        state.currentPhase = BotPhase.HOT_SWAP
                        return
                    }
                    delay(120L)
                }

                state.currentPhase = BotPhase.WAIT_GROWTH
            }

            BotPhase.HOT_SWAP -> {
                gestures.tap(state.points.shopRoofAlert, 55L)
                delay(320L)

                repeat(3) { wave ->
                    if (!state.isRunning || state.availableStacksToSell <= 0) return@repeat
                    state.statusLog = "Hot-Swap волна #${wave + 1}: сбор монет и докладка..."

                    collectSoldSlots()

                    val refillCount = min(state.availableStacksToSell, 4)
                    fillShopSlots(count = refillCount, placeAdOnLastSlot = false)

                    delay(1200L)
                }

                gestures.tap(state.points.deadStopGrass, 80L)
                delay(250L)
                state.currentPhase = BotPhase.CHECK_CAPACITY
            }

            BotPhase.WAIT_GROWTH -> {
                state.statusLog = "Ожидание созревания пшеницы (${state.maturityRemainingSec} с)..."
                if (state.maturityRemainingSec <= 0) {
                    state.currentPhase = BotPhase.CHECK_CAPACITY
                } else {
                    delay(500L)
                }
            }
        }
    }

    private suspend fun collectSoldSlots() {
        val slots = state.shopTotalSlots.coerceAtLeast(2)
        val stepX = (state.points.shopLastSlot.x - state.points.shopFirstSlot.x) / (slots - 1)
        for (i in 0 until slots) {
            val slotPt = PointF(state.points.shopFirstSlot.x + stepX * i, state.points.shopFirstSlot.y)
            gestures.tap(slotPt, 45L)
            delay(75L)
        }
    }

    private suspend fun fillShopSlots(count: Int, placeAdOnLastSlot: Boolean) {
        val slots = state.shopTotalSlots.coerceAtLeast(2)
        val stepX = (state.points.shopLastSlot.x - state.points.shopFirstSlot.x) / (slots - 1)

        for (i in 0 until count) {
            if (state.availableStacksToSell <= 0) break

            val isLastInBatch = (i == count - 1)
            val targetSlot = if (isLastInBatch && placeAdOnLastSlot) {
                state.points.shopLastSlot
            } else {
                PointF(state.points.shopFirstSlot.x + stepX * i, state.points.shopFirstSlot.y)
            }

            gestures.tap(targetSlot, 55L)
            delay(180L)

            val wheatItemInSiloPt = PointF(state.points.shopFirstSlot.x - 120f, state.points.shopFirstSlot.y - 40f)
            gestures.tap(wheatItemInSiloPt, 55L)
            delay(140L)

            if (isLastInBatch && placeAdOnLastSlot) {
                val adCheckboxPt = PointF(state.points.shopLastSlot.x - 80f, state.points.shopLastSlot.y + 110f)
                gestures.tap(adCheckboxPt, 55L)
                delay(110L)
                state.adCooldownRemainingSec = 300
            }

            val confirmPutPt = PointF(state.points.shopLastSlot.x - 80f, state.points.shopLastSlot.y + 210f)
            gestures.tap(confirmPutPt, 60L)
            delay(180L)

            state.siloCurrent = (state.siloCurrent - 10).coerceAtLeast(0)
            state.wheatCurrent = (state.wheatCurrent - 10).coerceAtLeast(0)
        }
        state.saveSettings()
    }

    private fun isExclamationAlertColor(color: Int): Boolean {
        val r = Color.red(color)
        val g = Color.green(color)
        val b = Color.blue(color)
        return (r > 200 && g < 75 && b < 75)
    }
}
