package com.taptap.haybot.engine

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.Build
import androidx.annotation.RequiresApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class GestureAndCameraController(private val service: AccessibilityService) {

    suspend fun tap(point: PointF, holdDurationMs: Long = 65L) {
        val path = Path().apply { moveTo(point.x, point.y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, holdDurationMs)
        dispatchGestureSuspend(GestureDescription.Builder().addStroke(stroke).build())
    }

    @RequiresApi(Build.VERSION_CODES.O)
    suspend fun executeFieldActionWithDeadStop(
        anchorField: PointF,
        toolIcon: PointF,
        fieldEnd: PointF,
        deadStopGrass: PointF,
        rowsCount: Int = 4,
        swipeDurationMs: Long = 1600L,
        useDeadStop: Boolean = true
    ) {
        tap(anchorField, holdDurationMs = 60L)
        delay(190L)

        val swipePath = Path().apply {
            moveTo(toolIcon.x, toolIcon.y)
            lineTo(fieldEnd.x, fieldEnd.y)

            val dyStep = (anchorField.y - fieldEnd.y) / rowsCount.coerceAtLeast(1)

            for (row in 0 until rowsCount) {
                val currentY = fieldEnd.y + dyStep * row
                val nextY = fieldEnd.y + dyStep * (row + 1)
                if (row % 2 == 0) {
                    lineTo(anchorField.x, currentY)
                    lineTo(anchorField.x, nextY)
                } else {
                    lineTo(fieldEnd.x, currentY)
                    lineTo(fieldEnd.x, nextY)
                }
            }

            if (useDeadStop) {
                lineTo(deadStopGrass.x, deadStopGrass.y)
            }
        }

        if (useDeadStop) {
            val moveStroke = GestureDescription.StrokeDescription(
                swipePath,
                0L,
                swipeDurationMs,
                true
            )

            val holdPath = Path().apply {
                moveTo(deadStopGrass.x, deadStopGrass.y)
                lineTo(deadStopGrass.x, deadStopGrass.y)
            }
            val deadStopStroke = moveStroke.continueStroke(
                holdPath,
                swipeDurationMs,
                95L,
                false
            )

            val gesture = GestureDescription.Builder()
                .addStroke(moveStroke)
                .addStroke(deadStopStroke)
                .build()

            dispatchGestureSuspend(gesture)

            delay(50L)
            tap(deadStopGrass, holdDurationMs = 105L)
        } else {
            val simpleStroke = GestureDescription.StrokeDescription(swipePath, 0L, swipeDurationMs)
            dispatchGestureSuspend(GestureDescription.Builder().addStroke(simpleStroke).build())
        }
    }

    private suspend fun dispatchGestureSuspend(gesture: GestureDescription): Boolean =
        suspendCancellableCoroutine { cont ->
            val callback = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }
            service.dispatchGesture(gesture, callback, null)
        }
}
