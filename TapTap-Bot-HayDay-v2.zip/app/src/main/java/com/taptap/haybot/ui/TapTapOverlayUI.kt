package com.taptap.haybot.ui

import android.graphics.PointF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.taptap.haybot.model.BotRuntimeState
import com.taptap.haybot.model.OverlayUiState
import kotlin.math.roundToInt

val BgDarkGlass = Color(0xE610151E)
val CardDarkGlass = Color(0xCC18202C)
val NeonCyan = Color(0xFF00E5FF)
val NeonCyanDark = Color(0xFF007A8C)
val NeonPinkRed = Color(0xFFFF2A6D)
val NeonPinkDark = Color(0xFF8A123B)
val NeonGreen = Color(0xFF00E676)
val TextPrimary = Color(0xFFF2F6FA)
val TextSecondary = Color(0xFF94A3B8)

val BorderCyanToPink = Brush.horizontalGradient(listOf(NeonCyan, NeonPinkRed))

@Composable
fun TapTapOverlayRoot(
    botState: BotRuntimeState,
    onStartStopClick: () -> Unit,
    onMoveOverlayWindow: (Float, Float) -> Unit
) {
    when (botState.uiState) {
        OverlayUiState.MINI_PILL -> {
            MiniPillBar(
                botState = botState,
                onStartStopClick = onStartStopClick,
                onCalibrateClick = { botState.uiState = OverlayUiState.CALIBRATION },
                onExpandClick = { botState.uiState = OverlayUiState.FULL_DASHBOARD },
                onDragWindow = onMoveOverlayWindow
            )
        }

        OverlayUiState.CALIBRATION -> {
            CalibrationScreenOverlay(
                botState = botState,
                onFinishCalibration = {
                    botState.saveSettings()
                    botState.uiState = OverlayUiState.MINI_PILL
                }
            )
        }

        OverlayUiState.FULL_DASHBOARD -> {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                MiniPillBar(
                    botState = botState,
                    onStartStopClick = onStartStopClick,
                    onCalibrateClick = { botState.uiState = OverlayUiState.CALIBRATION },
                    onExpandClick = { botState.uiState = OverlayUiState.MINI_PILL },
                    onDragWindow = onMoveOverlayWindow
                )
                Spacer(modifier = Modifier.height(8.dp))
                FullDashboardPanel(
                    botState = botState,
                    onCollapseClick = { botState.uiState = OverlayUiState.MINI_PILL }
                )
            }
        }
    }
}

@Composable
fun MiniPillBar(
    botState: BotRuntimeState,
    onStartStopClick: () -> Unit,
    onCalibrateClick: () -> Unit,
    onExpandClick: () -> Unit,
    onDragWindow: (Float, Float) -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(36.dp))
            .background(BgDarkGlass)
            .border(1.5.dp, BorderCyanToPink, RoundedCornerShape(36.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDragWindow(dragAmount.x, dragAmount.y)
                }
            },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row {
                    Text(
                        text = "Tap",
                        color = NeonCyan,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    )
                    Text(
                        text = "Tap",
                        color = NeonPinkRed,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    )
                }
                Text(
                    text = "Bot",
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(NeonCyan.copy(alpha = 0.35f), Color.Transparent)))
                    .border(1.dp, NeonCyan, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "🤖", fontSize = 18.sp)
            }
        }

        Box(
            modifier = Modifier
                .width(1.dp)
                .height(28.dp)
                .background(Color.White.copy(alpha = 0.15f))
        )

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(22.dp))
                .background(
                    Brush.horizontalGradient(
                        if (botState.isRunning) listOf(NeonPinkDark, NeonPinkRed)
                        else listOf(NeonCyanDark, NeonCyan.copy(alpha = 0.7f))
                    )
                )
                .border(1.dp, if (botState.isRunning) NeonPinkRed else NeonCyan, RoundedCornerShape(22.dp))
                .clickable { onStartStopClick() }
                .padding(horizontal = 16.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (botState.isRunning) "⏸ Стоп" else "▶ Старт",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(22.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xFF3A1C4A), NeonPinkDark)
                    )
                )
                .border(1.dp, NeonPinkRed.copy(alpha = 0.85f), RoundedCornerShape(22.dp))
                .clickable { onCalibrateClick() }
                .padding(horizontal = 14.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "⚙ Настроить",
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp
            )
        }

        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(NeonPinkDark.copy(alpha = 0.65f))
                .border(1.5.dp, NeonPinkRed, CircleShape)
                .clickable { onExpandClick() },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (botState.uiState == OverlayUiState.FULL_DASHBOARD) "︽" else "︾",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        }
    }
}

@Composable
fun CalibrationScreenOverlay(
    botState: BotRuntimeState,
    onFinishCalibration: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawLine(
                color = NeonCyan.copy(alpha = 0.6f),
                start = Offset(botState.points.anchorField.x, botState.points.anchorField.y),
                end = Offset(botState.points.fieldEnd.x, botState.points.fieldEnd.y),
                strokeWidth = 4f
            )
            drawLine(
                color = NeonPinkRed.copy(alpha = 0.6f),
                start = Offset(botState.points.fieldEnd.x, botState.points.fieldEnd.y),
                end = Offset(botState.points.deadStopGrass.x, botState.points.deadStopGrass.y),
                strokeWidth = 4f
            )
        }

        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 16.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(BgDarkGlass)
                .border(1.5.dp, BorderCyanToPink, RoundedCornerShape(30.dp))
                .padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "🎯 Перетащите прицелы на объекты фермы",
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(NeonCyanDark)
                    .border(1.dp, NeonCyan, RoundedCornerShape(18.dp))
                    .clickable { onFinishCalibration() }
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text("✓ Готово", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        DraggableTargetPin("1. Якорь поля", botState.points.anchorField, NeonCyan)
        DraggableTargetPin("2. Иконка серпа/пшеницы", botState.points.toolIcon, NeonCyan)
        DraggableTargetPin("3. Дальний край поля", botState.points.fieldEnd, NeonCyan)
        DraggableTargetPin("4. Стоп-трава (Тормоз камеры)", botState.points.deadStopGrass, NeonGreen)
        DraggableTargetPin("5. Знак [!] Киоска", botState.points.shopRoofAlert, NeonPinkRed)
        DraggableTargetPin("6. Посл. слот (Реклама)", botState.points.shopLastSlot, NeonPinkRed)
    }
}

@Composable
fun DraggableTargetPin(label: String, point: PointF, color: Color) {
    var offsetX by remember { mutableFloatStateOf(point.x) }
    var offsetY by remember { mutableFloatStateOf(point.y) }

    Column(
        modifier = Modifier
            .offset { IntOffset((offsetX - 28.dp.toPx()).roundToInt(), (offsetY - 28.dp.toPx()).roundToInt()) }
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    offsetX += dragAmount.x
                    offsetY += dragAmount.y
                    point.x = offsetX
                    point.y = offsetY
                }
            },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.25f))
                .border(2.dp, color, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(color)
            )
        }
        Text(
            text = label,
            color = TextPrimary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .padding(top = 2.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(BgDarkGlass)
                .padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun FullDashboardPanel(
    botState: BotRuntimeState,
    onCollapseClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .width(650.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(BgDarkGlass)
            .border(1.5.dp, BorderCyanToPink, RoundedCornerShape(24.dp))
            .padding(14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(
            modifier = Modifier
                .weight(0.95f)
                .clip(RoundedCornerShape(18.dp))
                .background(CardDarkGlass)
                .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (botState.isRunning) NeonGreen else NeonPinkRed)
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = formatSecondsToHMS(botState.uptimeSeconds),
                    color = TextPrimary,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (botState.isRunning) "АКТИВЕН (${botState.currentPhase.title})" else "ОСТАНОВЛЕН",
                    color = if (botState.isRunning) NeonGreen else TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Активен", color = TextPrimary, fontSize = 14.sp)
                Switch(
                    checked = botState.isRunning,
                    onCheckedChange = { botState.isRunning = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = TextPrimary, checkedTrackColor = NeonGreen)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Hot-Swap [!]", color = TextPrimary, fontSize = 14.sp)
                Switch(
                    checked = botState.hotSwapEnabled,
                    onCheckedChange = { botState.hotSwapEnabled = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = TextPrimary, checkedTrackColor = NeonCyan)
                )
            }
        }

        Column(
            modifier = Modifier.weight(1.15f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(CardDarkGlass)
                    .border(1.dp, BorderCyanToPink, RoundedCornerShape(18.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Силос (${botState.siloCurrent}/${botState.siloCapacity})", color = TextPrimary, fontSize = 13.sp)
                    Text("${botState.siloFillPercent}%", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                NeonProgressBar(progress = botState.siloFillPercent / 100f, color = NeonCyan)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Амбар (Бонусы)", color = TextPrimary, fontSize = 13.sp)
                    Text("${botState.barnFillPercent}%", color = NeonPinkRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                NeonProgressBar(progress = botState.barnFillPercent / 100f, color = NeonPinkRed)
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(CardDarkGlass)
                    .border(1.dp, BorderCyanToPink, RoundedCornerShape(18.dp))
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Настройка полей (Резерв)", color = TextPrimary, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    RoundCounterButton(text = "−", borderColor = NeonCyan, textColor = NeonCyan) {
                        if (botState.fieldCount > 6) {
                            botState.fieldCount -= 6
                            botState.saveSettings()
                        }
                    }
                    Text(
                        text = "${botState.fieldCount}",
                        color = TextPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    RoundCounterButton(text = "+", borderColor = NeonPinkRed, textColor = NeonPinkRed) {
                        botState.fieldCount += 6
                        botState.saveSettings()
                    }
                }
            }
        }

        Column(
            modifier = Modifier.weight(1.0f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(CardDarkGlass)
                    .border(1.dp, NeonPinkRed.copy(alpha = 0.65f), RoundedCornerShape(18.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Active Tasks", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(NeonGreen))
                }

                Text(
                    text = "🌾 Рост: ${botState.maturityRemainingSec}с | 📰 Газета: ${botState.adCooldownRemainingSec}с",
                    color = NeonCyan,
                    fontSize = 11.sp
                )
                Text(
                    text = "📦 К продаже: ${botState.availableStacksToSell} слот. (Цена: ${botState.resolveActivePrice(4)} мон.)",
                    color = TextSecondary,
                    fontSize = 11.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Стоп-тап камеры", color = TextPrimary, fontSize = 12.sp)
                    Checkbox(
                        checked = botState.deadStopEnabled,
                        onCheckedChange = { botState.deadStopEnabled = it }
                    )
                }

                Text(
                    text = botState.statusLog,
                    color = TextPrimary.copy(alpha = 0.9f),
                    fontSize = 11.sp,
                    maxLines = 2
                )
            }

            Box(
                modifier = Modifier
                    .align(Alignment.End)
                    .clip(RoundedCornerShape(14.dp))
                    .background(CardDarkGlass)
                    .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
                    .clickable { onCollapseClick() }
                    .padding(horizontal = 18.dp, vertical = 8.dp)
            ) {
                Text("свернуть  ︽", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun NeonProgressBar(progress: Float, color: Color) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(Color.Black.copy(alpha = 0.5f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .fillMaxHeight()
                .clip(RoundedCornerShape(4.dp))
                .background(color)
        )
    }
}

@Composable
fun RoundCounterButton(text: String, borderColor: Color, textColor: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, borderColor.copy(alpha = 0.7f), RoundedCornerShape(10.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, color = textColor, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

private fun formatSecondsToHMS(totalSec: Long): String {
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return "%02d:%02d:%02d".format(h, m, s)
}
