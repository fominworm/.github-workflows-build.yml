package com.taptap.haybot.model

import android.content.Context
import android.graphics.PointF
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.floor
import kotlin.math.max

enum class OverlayUiState {
    MINI_PILL,
    CALIBRATION,
    FULL_DASHBOARD
}

enum class BotPhase(val title: String) {
    IDLE("ОЖИДАНИЕ"),
    CHECK_CAPACITY("АУДИТ СИЛОСА"),
    HARVEST("СБОР УРОЖАЯ"),
    PLANT("ПОСЕВ ПОЛЯ"),
    LOAD_SHOP("ЗАГРУЗКА КИОСКА"),
    CAMP_ALERT("ОХОТА НА [!]"),
    HOT_SWAP("ГОРЯЧАЯ ПОДМЕНА"),
    WAIT_GROWTH("РОСТ ПШЕНИЦЫ")
}

enum class PriceStrategy(val coins: Int, val label: String) {
    AUTO(0, "Авто"),
    MAX_36(36, "36 мон."),
    BASE_10(10, "10 мон."),
    DRAIN_1(1, "1 мон.")
}

data class CalibrationPoints(
    var anchorField: PointF = PointF(650f, 520f),
    var toolIcon: PointF = PointF(580f, 430f),
    var fieldEnd: PointF = PointF(1180f, 680f),
    var deadStopGrass: PointF = PointF(960f, 540f),
    var shopRoofAlert: PointF = PointF(420f, 790f),
    var shopFirstSlot: PointF = PointF(480f, 460f),
    var shopLastSlot: PointF = PointF(1420f, 460f)
)

class BotRuntimeState(context: Context) {
    private val prefs = context.getSharedPreferences("taptap_bot_prefs", Context.MODE_PRIVATE)

    var uiState by mutableStateOf(OverlayUiState.MINI_PILL)
    var isRunning by mutableStateOf(false)
    var currentPhase by mutableStateOf(BotPhase.IDLE)
    var statusLog by mutableStateOf("Готов к запуску")

    var hotSwapEnabled by mutableStateOf(true)
    var deadStopEnabled by mutableStateOf(true)
    var priceStrategy by mutableStateOf(PriceStrategy.AUTO)
    var swipeDurationMs by mutableLongStateOf(1600L)

    var fieldCount by mutableIntStateOf(prefs.getInt("field_count", 72))
    var siloCapacity by mutableIntStateOf(prefs.getInt("silo_cap", 300))
    var siloCurrent by mutableIntStateOf(prefs.getInt("silo_curr", 120))
    var wheatCurrent by mutableIntStateOf(prefs.getInt("wheat_curr", 90))
    var barnFillPercent by mutableIntStateOf(45)
    var shopTotalSlots by mutableIntStateOf(6)

    var uptimeSeconds by mutableLongStateOf(0L)
    var maturityRemainingSec by mutableIntStateOf(0)
    var adCooldownRemainingSec by mutableIntStateOf(0)

    var points by mutableStateOf(loadPoints())

    val seedReserve: Int
        get() = fieldCount

    val freeSiloSpace: Int
        get() = max(0, siloCapacity - siloCurrent)

    val canFullHarvestSafely: Boolean
        get() = freeSiloSpace >= (fieldCount * 2)

    val safeHarvestBatchCount: Int
        get() = if (canFullHarvestSafely) fieldCount else max(0, floor(freeSiloSpace / 2.0).toInt())

    val sellableWheatSurplus: Int
        get() = max(0, wheatCurrent - seedReserve)

    val availableStacksToSell: Int
        get() = sellableWheatSurplus / 10

    val siloFillPercent: Int
        get() = ((siloCurrent.toFloat() / siloCapacity.coerceAtLeast(1)) * 100).toInt().coerceIn(0, 100)

    fun resolveActivePrice(freeShopSlots: Int): Int {
        if (priceStrategy != PriceStrategy.AUTO) return priceStrategy.coins
        return when {
            freeSiloSpace < fieldCount || freeShopSlots <= 1 -> 1
            freeSiloSpace < fieldCount * 2 || freeShopSlots <= 3 -> 10
            else -> 36
        }
    }

    fun saveSettings() {
        prefs.edit().apply {
            putInt("field_count", fieldCount)
            putInt("silo_cap", siloCapacity)
            putInt("silo_curr", siloCurrent)
            putInt("wheat_curr", wheatCurrent)
            putFloat("anchor_x", points.anchorField.x)
            putFloat("anchor_y", points.anchorField.y)
            putFloat("tool_x", points.toolIcon.x)
            putFloat("tool_y", points.toolIcon.y)
            putFloat("end_x", points.fieldEnd.x)
            putFloat("end_y", points.fieldEnd.y)
            putFloat("stop_x", points.deadStopGrass.x)
            putFloat("stop_y", points.deadStopGrass.y)
            putFloat("alert_x", points.shopRoofAlert.x)
            putFloat("alert_y", points.shopRoofAlert.y)
            putFloat("last_slot_x", points.shopLastSlot.x)
            putFloat("last_slot_y", points.shopLastSlot.y)
            apply()
        }
    }

    private fun loadPoints(): CalibrationPoints {
        return CalibrationPoints(
            anchorField = PointF(prefs.getFloat("anchor_x", 650f), prefs.getFloat("anchor_y", 520f)),
            toolIcon = PointF(prefs.getFloat("tool_x", 580f), prefs.getFloat("tool_y", 430f)),
            fieldEnd = PointF(prefs.getFloat("end_x", 1180f), prefs.getFloat("end_y", 680f)),
            deadStopGrass = PointF(prefs.getFloat("stop_x", 960f), prefs.getFloat("stop_y", 540f)),
            shopRoofAlert = PointF(prefs.getFloat("alert_x", 420f), prefs.getFloat("alert_y", 790f)),
            shopLastSlot = PointF(prefs.getFloat("last_slot_x", 1420f), prefs.getFloat("last_slot_y", 460f))
        )
    }
}
