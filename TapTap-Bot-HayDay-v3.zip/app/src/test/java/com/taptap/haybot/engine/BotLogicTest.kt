package com.taptap.haybot.engine

import com.taptap.haybot.model.PriceStrategy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BotLogicTest {

    @Test
    fun safeHarvest_limitedBySiloSpace() {
        assertEquals(72, BotLogic.safeHarvestFields(300, 72))
        assertEquals(50, BotLogic.safeHarvestFields(100, 72))
        assertEquals(0, BotLogic.safeHarvestFields(1, 72))
        assertEquals(0, BotLogic.safeHarvestFields(-5, 72))
    }

    @Test
    fun rowsToCover_roundsUpAndClamps() {
        assertEquals(12, BotLogic.fieldsPerRow(72, 6))
        assertEquals(6, BotLogic.rowsToCover(72, 12, 6))
        assertEquals(2, BotLogic.rowsToCover(13, 12, 6))
        assertEquals(1, BotLogic.rowsToCover(1, 12, 6))
        assertEquals(0, BotLogic.rowsToCover(0, 12, 6))
        assertEquals(6, BotLogic.rowsToCover(500, 12, 6))
    }

    @Test
    fun resolvePrice_autoAndFixed() {
        assertEquals(36, BotLogic.resolvePrice(PriceStrategy.AUTO, 300, 72, 6))
        assertEquals(10, BotLogic.resolvePrice(PriceStrategy.AUTO, 100, 72, 6))
        assertEquals(1, BotLogic.resolvePrice(PriceStrategy.AUTO, 10, 72, 6))
        assertEquals(1, BotLogic.resolvePrice(PriceStrategy.AUTO, 300, 72, 1))
        assertEquals(10, BotLogic.resolvePrice(PriceStrategy.BASE_10, 0, 72, 1))
    }

    @Test
    fun priceMinusTaps_countsFromMax() {
        assertEquals(0, BotLogic.priceMinusTaps(36))
        assertEquals(26, BotLogic.priceMinusTaps(10))
        assertEquals(35, BotLogic.priceMinusTaps(1))
    }

    @Test
    fun alertDetection_usesBaseline() {
        val red = 0xFFFF0000.toInt()
        val green = 0xFF00FF00.toInt()
        assertTrue(BotLogic.isAlertRed(red))
        assertFalse(BotLogic.isAlertRed(green))
        assertEquals(0.5f, BotLogic.redFraction(intArrayOf(red, red, green, green)), 0.001f)

        assertTrue(BotLogic.isAlert(0.4f, 0.0f))
        assertFalse(BotLogic.isAlert(0.4f, 0.35f))   // красная крыша была и раньше
        assertFalse(BotLogic.isAlert(0.1f, 0.0f))
    }
}
