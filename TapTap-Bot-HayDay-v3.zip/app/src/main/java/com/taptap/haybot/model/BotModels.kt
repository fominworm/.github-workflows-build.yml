package com.taptap.haybot.model

import android.content.Context
import android.graphics.PointF
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import com.taptap.haybot.engine.BotLogic
import kotlin.math.max

enum class OverlayUiState {
    MINI_PILL,
    CALIBRATION,
    FULL_DASHBOARD
}

enum class BotPhase(val title: String) {
    IDLE("ОЖИДАНИЕ"),
    CHECK_CAPACITY("АУДИТ СИЛОСА"),
    HARVEST("СБОР УРОЖАЯ"),
    PLANT("ПОСЕВ ПОЛЯ"),
    LOAD_SHOP("ЗАГРУЗКА КИОСКА"),
    CAMP_ALERT("ОХОТА НА [!]"),
    HOT_SWAP("ГОРЯЧАЯ ПОДМЕНА"),
    WAIT_GROWTH("РОСТ ПШЕНИЦЫ")
}

enum class PriceStrategy(val coins: Int, val label: String) {
    AUTO(0, "Авто"),
    MAX_36(36, "36 мон."),
    BASE_10(10, "10 мон."),
    DRAIN_1(1, "1 мон.")
}

enum class PinGroup { FIELD, CAMERA, SHOP }

/**
 * Прицелы калибровки. Координаты хранятся ДОЛЯМИ экрана (0..1),
 * поэтому не ломаются при другом разрешении телефона.
 */
enum class PinId(val label: String, val defX: Float, val defY: Float, val group: PinGroup) {
    ANCHOR_FIELD("1 Якорь поля", 0.34f, 0.50f, PinGroup.FIELD),
    TOOL_SICKLE("2 Серп", 0.30f, 0.38f, PinGroup.FIELD),
    TOOL_WHEAT("3 Пшеница (посев)", 0.30f, 0.62f, PinGroup.FIELD),
    FIELD_END("4 Дальний край", 0.62f, 0.66f, PinGroup.FIELD),
    DEAD_STOP("5 Стоп-трава", 0.50f, 0.25f, PinGroup.CAMERA),
    SHOP_ALERT("6 Знак [!] киоска", 0.20f, 0.75f, PinGroup.SHOP),
    SHOP_FIRST_SLOT("7 Первый слот", 0.26f, 0.42f, PinGroup.SHOP),
    SHOP_LAST_SLOT("8 Посл. слот (реклама)", 0.74f, 0.42f, PinGroup.SHOP),
    SHOP_ITEM("9 Пшеница в списке", 0.18f, 0.58f, PinGroup.SHOP),
    PRICE_MAX("10 Макс. цена", 0.82f, 0.56f, PinGroup.SHOP),
    PRICE_MINUS("11 Цена −", 0.72f, 0.56f, PinGroup.SHOP),
    AD_CHECKBOX("12 Галочка рекламы", 0.82f, 0.68f, PinGroup.SHOP),
    CONFIRM_PUT("13 Выставить", 0.82f, 0.80f, PinGroup.SHOP)
}

data class NPoint(val x: Float, val y: Float)

class BotRuntimeState(context: Context) {
    private val prefs = context.getSharedPreferences("taptap_bot_prefs", Context.MODE_PRIVATE)

    // ---- UI / рантайм ----
    var uiState by mutableStateOf(OverlayUiState.MINI_PILL)
    var isRunning by mutableStateOf(false)
    var currentPhase by mutableStateOf(BotPhase.IDLE)
    var statusLog by mutableStateOf("Готов к запуску")
    var uptimeSeconds by mutableStateOf(0L)

    // ---- Размер экрана (px) ----
    var screenWidth by mutableIntStateOf(1920)
        private set
    var screenHeight by mutableIntStateOf(1080)
        private set

    // ---- Настройки (сохраняются) ----
    var hotSwapEnabled by mutableStateOf(prefs.getBoolean("hot_swap", true))
    var deadStopEnabled by mutableStateOf(prefs.getBoolean("dead_stop", true))
    var priceStrategy by mutableStateOf(loadPriceStrategy())
    var swipeDurationMs by mutableStateOf(prefs.getLong("swipe_ms", 1600L))

    var fieldCount by mutableIntStateOf(prefs.getInt("field_count", 72))
    var fieldRows by mutableIntStateOf(prefs.getInt("field_rows", 6))
    var siloCapacity by mutableIntStateOf(prefs.getInt("silo_cap", 300))
    var siloCurrent by mutableIntStateOf(prefs.getInt("silo_curr", 120))
    var wheatCurrent by mutableIntStateOf(prefs.getInt("wheat_curr", 90))
    var shopTotalSlots by mutableIntStateOf(prefs.getInt("shop_slots", 6))

    // ---- Таймеры по дедлайнам (переживают перезапуск бота) ----
    private var maturityDeadlineMs: Long = prefs.getLong("maturity_deadline", 0L)
    private var adDeadlineMs: Long = prefs.getLong("ad_deadline", 0L)
    var maturityRemainingSec by mutableIntStateOf(0)
        private set
    var adCooldownRemainingSec by mutableIntStateOf(0)
        private set

    // ---- Прицелы (доли экрана) ----
    val pins = mutableStateMapOf<PinId, NPoint>()

    init {
        for (id in PinId.values()) {
            pins[id] = NPoint(
                prefs.getFloat("pin_${id.name}_x", id.defX),
                prefs.getFloat("pin_${id.name}_y", id.defY)
            )
        }
        refreshTimers()
    }

    // ---- Прицелы: доступ ----
    fun frac(id: PinId): NPoint = pins[id] ?: NPoint(id.defX, id.defY)

    fun px(id: PinId): PointF {
        val f = frac(id)
        return PointF(f.x * screenWidth, f.y * screenHeight)
    }

    fun offsetOf(id: PinId): Offset {
        val f = frac(id)
        return Offset(f.x * screenWidth, f.y * screenHeight)
    }

    fun movePinPx(id: PinId, dxPx: Float, dyPx: Float) {
        val f = frac(id)
        val w = screenWidth.coerceAtLeast(1)
        val h = screenHeight.coerceAtLeast(1)
        pins[id] = NPoint(
            (f.x + dxPx / w).coerceIn(0f, 1f),
            (f.y + dyPx / h).coerceIn(0f, 1f)
        )
    }

    fun resetPins() {
        for (id in PinId.values()) pins[id] = NPoint(id.defX, id.defY)
    }

    fun updateScreen(width: Int, height: Int) {
        if (width > 0 && height > 0) {
            screenWidth = width
            screenHeight = height
        }
    }

    // ---- Таймеры ----
    fun startGrowth(sec: Int) {
        maturityDeadlineMs = System.currentTimeMillis() + sec * 1000L
        refreshTimers()
        saveSettings()
    }

    fun startAdCooldown(sec: Int) {
        adDeadlineMs = System.currentTimeMillis() + sec * 1000L
        refreshTimers()
        saveSettings()
    }

    fun refreshTimers() {
        val now = System.currentTimeMillis()
        maturityRemainingSec = max(0L, (maturityDeadlineMs - now + 999L) / 1000L).toInt()
        adCooldownRemainingSec = max(0L, (adDeadlineMs - now + 999L) / 1000L).toInt()
    }

    // ---- Производные значения ----
    val seedReserve: Int
        get() = fieldCount

    val freeSiloSpace: Int
        get() = max(0, siloCapacity - siloCurrent)

    val safeHarvestFields: Int
        get() = BotLogic.safeHarvestFields(freeSiloSpace, fieldCount)

    val canFullHarvestSafely: Boolean
        get() = safeHarvestFields >= fieldCount

    val sellableWheatSurplus: Int
        get() = max(0, wheatCurrent - seedReserve)

    val availableStacksToSell: Int
        get() = sellableWheatSurplus / BotLogic.STACK_SIZE

    val siloFillPercent: Int
        get() = ((siloCurrent.toFloat() / siloCapacity.coerceAtLeast(1)) * 100).toInt().coerceIn(0, 100)

    val wheatFillPercent: Int
        get() = ((wheatCurrent.toFloat() / siloCapacity.coerceAtLeast(1)) * 100).toInt().coerceIn(0, 100)

    fun resolveActivePrice(freeShopSlots: Int): Int =
        BotLogic.resolvePrice(priceStrategy, freeSiloSpace, fieldCount, freeShopSlots)

    // ---- Сохранение ----
    fun saveSettings() {
        prefs.edit().apply {
            putBoolean("hot_swap", hotSwapEnabled)
            putBoolean("dead_stop", deadStopEnabled)
            putString("price_strategy", priceStrategy.name)
            putLong("swipe_ms", swipeDurationMs)
            putInt("field_count", fieldCount)
            putInt("field_rows", fieldRows)
            putInt("silo_cap", siloCapacity)
            putInt("silo_curr", siloCurrent)
            putInt("wheat_curr", wheatCurrent)
            putInt("shop_slots", shopTotalSlots)
            putLong("maturity_deadline", maturityDeadlineMs)
            putLong("ad_deadline", adDeadlineMs)
            for (id in PinId.values()) {
                val f = frac(id)
                putFloat("pin_${id.name}_x", f.x)
                putFloat("pin_${id.name}_y", f.y)
            }
            apply()
        }
    }

    private fun loadPriceStrategy(): PriceStrategy =
        runCatching { PriceStrategy.valueOf(prefs.getString("price_strategy", "AUTO") ?: "AUTO") }
            .getOrDefault(PriceStrategy.AUTO)
}
