package com.taptap.haybot.engine

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Все жесты возвращают true/false — движок знает, выполнился ли жест,
 * и не зависает, если система отклонила или отменила его.
 */
class GestureController(private val service: AccessibilityService) {

    suspend fun tap(point: PointF, holdMs: Long = 65L): Boolean {
        val hold = holdMs.coerceAtLeast(1L)
        val path = Path().apply { moveTo(point.x, point.y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, hold)
        return dispatch(GestureDescription.Builder().addStroke(stroke).build(), hold)
    }

    /**
     * Нажать на якорь поля, затем провести «змейкой» от иконки инструмента по рядам.
     * [rowsToCover] из [rowsTotal] — позволяет собирать/сажать только часть поля.
     * Dead-Stop: удержание на траве в конце, чтобы камера не «уехала» по инерции.
     * Удержание идёт ВТОРЫМ жестом (continueStroke нельзя класть в тот же жест).
     */
    suspend fun executeFieldAction(
        anchor: PointF,
        tool: PointF,
        fieldEnd: PointF,
        deadStop: PointF,
        rowsTotal: Int,
        rowsToCover: Int,
        swipeDurationMs: Long,
        useDeadStop: Boolean
    ): Boolean {
        if (!tap(anchor, 60L)) return false
        delay(190L)

        val total = rowsTotal.coerceAtLeast(1)
        val rows = rowsToCover.coerceIn(1, total)
        val duration = (swipeDurationMs * rows / total).coerceAtLeast(500L)
        val path = buildSerpentine(tool, anchor, fieldEnd, total, rows, if (useDeadStop) deadStop else null)

        if (!useDeadStop) {
            val stroke = GestureDescription.StrokeDescription(path, 0L, duration)
            return dispatch(GestureDescription.Builder().addStroke(stroke).build(), duration)
        }

        val move = GestureDescription.StrokeDescription(path, 0L, duration, true)
        if (!dispatch(GestureDescription.Builder().addStroke(move).build(), duration)) return false

        val holdPath = Path().apply { moveTo(deadStop.x, deadStop.y) }
        val hold = move.continueStroke(holdPath, 0L, DEAD_STOP_HOLD_MS, false)
        return dispatch(GestureDescription.Builder().addStroke(hold).build(), DEAD_STOP_HOLD_MS)
    }

    private fun buildSerpentine(
        tool: PointF,
        anchor: PointF,
        end: PointF,
        totalRows: Int,
        rows: Int,
        stop: PointF?
    ): Path {
        val path = Path()
        path.moveTo(tool.x, tool.y)
        val dy = if (totalRows > 1) (end.y - anchor.y) / (totalRows - 1) else 0f
        for (row in 0 until rows) {
            val y = anchor.y + dy * row
            val leftToRight = row % 2 == 0
            val startX = if (leftToRight) anchor.x else end.x
            val endX = if (leftToRight) end.x else anchor.x
            path.lineTo(startX, y)
            path.lineTo(endX, y)
        }
        if (stop != null) path.lineTo(stop.x, stop.y)
        return path
    }

    private suspend fun dispatch(gesture: GestureDescription, expectedMs: Long): Boolean {
        val result = withTimeoutOrNull(expectedMs + 4000L) {
            suspendCancellableCoroutine<Boolean> { cont ->
                val callback = object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(false)
                    }
                }
                // Если dispatchGesture вернул false — колбэк НЕ вызовется, поэтому резюмируем сами.
                val accepted = try {
                    service.dispatchGesture(gesture, callback, null)
                } catch (e: Exception) {
                    false
                }
                if (!accepted && cont.isActive) cont.resume(false)
            }
        }
        return result ?: false
    }

    private companion object {
        const val DEAD_STOP_HOLD_MS = 95L
    }
}
