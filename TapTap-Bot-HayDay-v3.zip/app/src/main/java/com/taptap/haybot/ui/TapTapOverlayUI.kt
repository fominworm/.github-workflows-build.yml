package com.taptap.haybot.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.taptap.haybot.model.BotRuntimeState
import com.taptap.haybot.model.OverlayUiState
import com.taptap.haybot.model.PinGroup
import com.taptap.haybot.model.PinId
import com.taptap.haybot.model.PriceStrategy
import kotlin.math.roundToInt

val BgDarkGlass = Color(0xE610151E)
val CardDarkGlass = Color(0xCC18202C)
val NeonCyan = Color(0xFF00E5FF)
val NeonCyanDark = Color(0xFF007A8C)
val NeonPinkRed = Color(0xFFFF2A6D)
val NeonPinkDark = Color(0xFF8A123B)
val NeonGreen = Color(0xFF00E676)
val TextPrimary = Color(0xFFF2F6FA)
val TextSecondary = Color(0xFF94A3B8)

val BorderCyanToPink = Brush.horizontalGradient(listOf(NeonCyan, NeonPinkRed))

@Composable
fun TapTapOverlayRoot(
    botState: BotRuntimeState,
    onStartStopClick: () -> Unit,
    onMoveOverlayWindow: (Float, Float) -> Unit
) {
    when (botState.uiState) {
        OverlayUiState.MINI_PILL -> {
            MiniPillBar(
                botState = botState,
                onStartStopClick = onStartStopClick,
                onCalibrateClick = { botState.uiState = OverlayUiState.CALIBRATION },
                onExpandClick = { botState.uiState = OverlayUiState.FULL_DASHBOARD },
                onDragWindow = onMoveOverlayWindow
            )
        }

        OverlayUiState.CALIBRATION -> {
            CalibrationScreenOverlay(
                botState = botState,
                onFinishCalibration = {
                    botState.saveSettings()
                    botState.uiState = OverlayUiState.MINI_PILL
                }
            )
        }

        OverlayUiState.FULL_DASHBOARD -> {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                MiniPillBar(
                    botState = botState,
                    onStartStopClick = onStartStopClick,
                    onCalibrateClick = { botState.uiState = OverlayUiState.CALIBRATION },
                    onExpandClick = { botState.uiState = OverlayUiState.MINI_PILL },
                    onDragWindow = onMoveOverlayWindow
                )
                Spacer(modifier = Modifier.height(8.dp))
                FullDashboardPanel(
                    botState = botState,
                    onToggleRun = onStartStopClick,
                    onCollapseClick = { botState.uiState = OverlayUiState.MINI_PILL }
                )
            }
        }
    }
}

@Composable
fun MiniPillBar(
    botState: BotRuntimeState,
    onStartStopClick: () -> Unit,
    onCalibrateClick: () -> Unit,
    onExpandClick: () -> Unit,
    onDragWindow: (Float, Float) -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(36.dp))
            .background(BgDarkGlass)
            .border(1.5.dp, BorderCyanToPink, RoundedCornerShape(36.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDragWindow(dragAmount.x, dragAmount.y)
                }
            },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row {
                    Text(text = "Tap", color = NeonCyan, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Text(text = "Tap", color = NeonPinkRed, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                }
                Text(text = "Bot", color = TextSecondary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }

            Spacer(modifier = Modifier.width(8.dp))

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(NeonCyan.copy(alpha = 0.35f), Color.Transparent)))
                    .border(1.dp, NeonCyan, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "🤖", fontSize = 18.sp)
            }
        }

        Box(
            modifier = Modifier
                .width(1.dp)
                .height(28.dp)
                .background(Color.White.copy(alpha = 0.15f))
        )

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(22.dp))
                .background(
                    Brush.horizontalGradient(
                        if (botState.isRunning) listOf(NeonPinkDark, NeonPinkRed)
                        else listOf(NeonCyanDark, NeonCyan.copy(alpha = 0.7f))
                    )
                )
                .border(1.dp, if (botState.isRunning) NeonPinkRed else NeonCyan, RoundedCornerShape(22.dp))
                .clickable { onStartStopClick() }
                .padding(horizontal = 16.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (botState.isRunning) "⏸ Стоп" else "▶ Старт",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF3A1C4A), NeonPinkDark)))
                .border(1.dp, NeonPinkRed.copy(alpha = 0.85f), RoundedCornerShape(22.dp))
                .clickable { onCalibrateClick() }
                .padding(horizontal = 14.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "⚙ Настроить",
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp
            )
        }

        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(NeonPinkDark.copy(alpha = 0.65f))
                .border(1.5.dp, NeonPinkRed, CircleShape)
                .clickable { onExpandClick() },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (botState.uiState == OverlayUiState.FULL_DASHBOARD) "▲" else "▼",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        }
    }
}

// ----------------------------------------------------------------- калибровка

@Composable
fun CalibrationScreenOverlay(
    botState: BotRuntimeState,
    onFinishCalibration: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            // Реальный размер окна = размер экрана: по нему считаются доли координат.
            .onSizeChanged { botState.updateScreen(it.width, it.height) }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val a = botState.offsetOf(PinId.ANCHOR_FIELD)
            val e = botState.offsetOf(PinId.FIELD_END)
            val stop = botState.offsetOf(PinId.DEAD_STOP)
            val first = botState.offsetOf(PinId.SHOP_FIRST_SLOT)
            val last = botState.offsetOf(PinId.SHOP_LAST_SLOT)

            // Предпросмотр рядов «змейки»
            val rows = botState.fieldRows.coerceAtLeast(1)
            val dy = if (rows > 1) (e.y - a.y) / (rows - 1) else 0f
            for (r in 0 until rows) {
                val y = a.y + dy * r
                drawLine(
                    color = NeonCyan.copy(alpha = 0.35f),
                    start = Offset(a.x, y),
                    end = Offset(e.x, y),
                    strokeWidth = 3f
                )
            }
            drawLine(NeonPinkRed.copy(alpha = 0.6f), e, stop, 4f)
            drawLine(NeonPinkRed.copy(alpha = 0.35f), first, last, 3f)
        }

        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 16.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(BgDarkGlass)
                .border(1.5.dp, BorderCyanToPink, RoundedCornerShape(30.dp))
                .padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "🎯 Перетащите прицелы на объекты",
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(NeonPinkDark)
                    .border(1.dp, NeonPinkRed, RoundedCornerShape(18.dp))
                    .clickable { botState.resetPins() }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("↺ Сброс", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(NeonCyanDark)
                    .border(1.dp, NeonCyan, RoundedCornerShape(18.dp))
                    .clickable { onFinishCalibration() }
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text("✓ Готово", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        for (id in PinId.values()) {
            DraggableTargetPin(botState = botState, id = id)
        }
    }
}

@Composable
fun DraggableTargetPin(botState: BotRuntimeState, id: PinId) {
    val color = when (id.group) {
        PinGroup.FIELD -> NeonCyan
        PinGroup.CAMERA -> NeonGreen
        PinGroup.SHOP -> NeonPinkRed
    }
    var widthPx by remember { mutableIntStateOf(0) }
    val circleRadiusPx = with(LocalDensity.current) { 21.dp.toPx() }

    Column(
        modifier = Modifier
            .onSizeChanged { widthPx = it.width }
            .offset {
                val p = botState.offsetOf(id)
                IntOffset((p.x - widthPx / 2f).roundToInt(), (p.y - circleRadiusPx).roundToInt())
            }
            .pointerInput(id) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    botState.movePinPx(id, dragAmount.x, dragAmount.y)
                }
            },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.25f))
                .border(2.dp, color, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(color)
            )
        }
        Text(
            text = id.label,
            color = TextPrimary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .padding(top = 2.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(BgDarkGlass)
                .padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

// ------------------------------------------------------------------ дашборд

@Composable
fun FullDashboardPanel(
    botState: BotRuntimeState,
    onToggleRun: () -> Unit,
    onCollapseClick: () -> Unit
) {
    val screenWidthDp = LocalConfiguration.current.screenWidthDp
    val panelWidth = minOf(650, screenWidthDp - 24).coerceAtLeast(320).dp

    Row(
        modifier = Modifier
            .width(panelWidth)
            .heightIn(max = 300.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(BgDarkGlass)
            .border(1.5.dp, BorderCyanToPink, RoundedCornerShape(24.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // --- Колонка 1: статус и переключатели
        Column(
            modifier = Modifier
                .weight(0.95f)
                .clip(RoundedCornerShape(18.dp))
                .background(CardDarkGlass)
                .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (botState.isRunning) NeonGreen else NeonPinkRed)
                )
            }

            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = formatSecondsToHMS(botState.uptimeSeconds),
                    color = TextPrimary,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (botState.isRunning) "АКТИВЕН (${botState.currentPhase.title})" else "ОСТАНОВЛЕН",
                    color = if (botState.isRunning) NeonGreen else TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

            LabeledSwitch("Активен", botState.isRunning, NeonGreen) { wanted ->
                // Настоящий запуск/остановка движка, а не просто флаг.
                if (wanted != botState.isRunning) onToggleRun()
            }
            LabeledSwitch("Hot-Swap [!]", botState.hotSwapEnabled, NeonCyan) {
                botState.hotSwapEnabled = it
                botState.saveSettings()
            }
            LabeledSwitch("Стоп-тап камеры", botState.deadStopEnabled, NeonCyan) {
                botState.deadStopEnabled = it
                botState.saveSettings()
            }
        }

        // --- Колонка 2: ресурсы и ручная коррекция
        Column(
            modifier = Modifier
                .weight(1.15f)
                .clip(RoundedCornerShape(18.dp))
                .background(CardDarkGlass)
                .border(1.dp, BorderCyanToPink, RoundedCornerShape(18.dp))
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Силос (${botState.siloCurrent}/${botState.siloCapacity})", color = TextPrimary, fontSize = 12.sp)
                Text("${botState.siloFillPercent}%", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            NeonProgressBar(progress = botState.siloFillPercent / 100f, color = NeonCyan)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Пшеница (${botState.wheatCurrent})", color = TextPrimary, fontSize = 12.sp)
                Text("${botState.wheatFillPercent}%", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            NeonProgressBar(progress = botState.wheatFillPercent / 100f, color = NeonGreen)

            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
            Text("Поле и склад (ручная коррекция)", color = TextSecondary, fontSize = 11.sp)

            Stepper(
                label = "Грядок",
                value = "${botState.fieldCount}",
                onMinus = { if (botState.fieldCount > 6) botState.fieldCount -= 6; botState.saveSettings() },
                onPlus = { botState.fieldCount += 6; botState.saveSettings() }
            )
            Stepper(
                label = "Рядов поля",
                value = "${botState.fieldRows}",
                onMinus = { if (botState.fieldRows > 1) botState.fieldRows -= 1; botState.saveSettings() },
                onPlus = { if (botState.fieldRows < 12) botState.fieldRows += 1; botState.saveSettings() }
            )
            Stepper(
                label = "Слотов киоска",
                value = "${botState.shopTotalSlots}",
                onMinus = { if (botState.shopTotalSlots > 2) botState.shopTotalSlots -= 1; botState.saveSettings() },
                onPlus = { if (botState.shopTotalSlots < 10) botState.shopTotalSlots += 1; botState.saveSettings() }
            )
            Stepper(
                label = "Вместимость",
                value = "${botState.siloCapacity}",
                onMinus = { if (botState.siloCapacity > 50) botState.siloCapacity -= 50; botState.saveSettings() },
                onPlus = { botState.siloCapacity += 50; botState.saveSettings() }
            )
            Stepper(
                label = "В силосе",
                value = "${botState.siloCurrent}",
                onMinus = { botState.siloCurrent = (botState.siloCurrent - 10).coerceAtLeast(0); botState.saveSettings() },
                onPlus = {
                    botState.siloCurrent = (botState.siloCurrent + 10).coerceAtMost(botState.siloCapacity)
                    botState.saveSettings()
                }
            )
            Stepper(
                label = "Пшеницы",
                value = "${botState.wheatCurrent}",
                onMinus = { botState.wheatCurrent = (botState.wheatCurrent - 10).coerceAtLeast(0); botState.saveSettings() },
                onPlus = {
                    botState.wheatCurrent = (botState.wheatCurrent + 10).coerceAtMost(botState.siloCapacity)
                    botState.saveSettings()
                }
            )
        }

        // --- Колонка 3: задачи, цена, лог
        Column(
            modifier = Modifier.weight(1.0f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(CardDarkGlass)
                    .border(1.dp, NeonPinkRed.copy(alpha = 0.65f), RoundedCornerShape(18.dp))
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Active Tasks", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (botState.isRunning) NeonGreen else NeonPinkRed)
                    )
                }

                Text(
                    text = "🌾 Рост: ${botState.maturityRemainingSec}с | 📰 Газета: ${botState.adCooldownRemainingSec}с",
                    color = NeonCyan,
                    fontSize = 11.sp
                )
                Text(
                    text = "📦 К продаже: ${botState.availableStacksToSell} слот. " +
                            "(цена: ${botState.resolveActivePrice(botState.shopTotalSlots)} мон.)",
                    color = TextSecondary,
                    fontSize = 11.sp
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.06f))
                        .border(1.dp, NeonCyan.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                        .clickable {
                            val all = PriceStrategy.values()
                            botState.priceStrategy = all[(botState.priceStrategy.ordinal + 1) % all.size]
                            botState.saveSettings()
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Цена: ${botState.priceStrategy.label}  ⟳",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Text(
                    text = botState.statusLog,
                    color = TextPrimary.copy(alpha = 0.9f),
                    fontSize = 11.sp,
                    maxLines = 4
                )
            }

            Box(
                modifier = Modifier
                    .align(Alignment.End)
                    .clip(RoundedCornerShape(14.dp))
                    .background(CardDarkGlass)
                    .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
                    .clickable { onCollapseClick() }
                    .padding(horizontal = 18.dp, vertical = 8.dp)
            ) {
                Text("свернуть  ▲", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun LabeledSwitch(
    label: String,
    checked: Boolean,
    trackColor: Color,
    onChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextPrimary, fontSize = 13.sp)
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = TextPrimary, checkedTrackColor = trackColor)
        )
    }
}

@Composable
private fun Stepper(
    label: String,
    value: String,
    onMinus: () -> Unit,
    onPlus: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(label, color = TextPrimary, fontSize = 12.sp, modifier = Modifier.weight(1f))
        RoundCounterButton(text = "−", borderColor = NeonCyan, textColor = NeonCyan, size = 28.dp, onClick = onMinus)
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(min = 38.dp)
        )
        RoundCounterButton(text = "+", borderColor = NeonPinkRed, textColor = NeonPinkRed, size = 28.dp, onClick = onPlus)
    }
}

@Composable
fun NeonProgressBar(progress: Float, color: Color) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(Color.Black.copy(alpha = 0.5f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .fillMaxHeight()
                .clip(RoundedCornerShape(4.dp))
                .background(color)
        )
    }
}

@Composable
fun RoundCounterButton(
    text: String,
    borderColor: Color,
    textColor: Color,
    size: Dp = 36.dp,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, borderColor.copy(alpha = 0.7f), RoundedCornerShape(10.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

private fun formatSecondsToHMS(totalSec: Long): String {
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return "%02d:%02d:%02d".format(h, m, s)
}
