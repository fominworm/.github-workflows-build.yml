package com.taptap.haybot.engine

import com.taptap.haybot.model.PriceStrategy
import kotlin.math.max
import kotlin.math.min

/**
 * Чистая логика бота без зависимостей от Android — её можно тестировать юнит-тестами.
 */
object BotLogic {
    const val WHEAT_YIELD = 2          // пшеницы с одной грядки
    const val STACK_SIZE = 10          // штук пшеницы в одном слоте киоска
    const val GROWTH_SEC = 120         // время роста пшеницы
    const val AD_COOLDOWN_SEC = 300    // пауза до следующего объявления в газете
    const val MAX_PRICE = 36           // максимальная цена за стек

    /** Сколько грядок можно собрать, чтобы не переполнить силос. */
    fun safeHarvestFields(freeSpace: Int, fieldCount: Int): Int =
        min(fieldCount, max(0, freeSpace) / WHEAT_YIELD).coerceAtLeast(0)

    /** Сколько грядок в одном ряду. */
    fun fieldsPerRow(fieldCount: Int, rows: Int): Int {
        val r = rows.coerceAtLeast(1)
        return ((fieldCount + r - 1) / r).coerceAtLeast(1)
    }

    /** Сколько рядов надо пройти, чтобы покрыть [fields] грядок. */
    fun rowsToCover(fields: Int, perRow: Int, totalRows: Int): Int {
        if (fields <= 0) return 0
        val p = perRow.coerceAtLeast(1)
        val needed = (fields + p - 1) / p
        return needed.coerceIn(1, totalRows.coerceAtLeast(1))
    }

    /** Выбор цены в режиме «Авто». */
    fun resolvePrice(
        strategy: PriceStrategy,
        freeSiloSpace: Int,
        fieldCount: Int,
        freeShopSlots: Int
    ): Int {
        if (strategy != PriceStrategy.AUTO) return strategy.coins
        return when {
            freeSiloSpace < fieldCount || freeShopSlots <= 1 -> 1
            freeSiloSpace < fieldCount * 2 || freeShopSlots <= 3 -> 10
            else -> MAX_PRICE
        }
    }

    /** Сколько раз нажать «−» после кнопки максимальной цены. */
    fun priceMinusTaps(price: Int): Int = (MAX_PRICE - price).coerceIn(0, MAX_PRICE)

    /** Красный пиксель знака [!] (ARGB Int). */
    fun isAlertRed(color: Int): Boolean {
        val r = (color shr 16) and 0xFF
        val g = (color shr 8) and 0xFF
        val b = color and 0xFF
        return r >= 190 && g <= 90 && b <= 90
    }

    /** Доля «красных» пикселей в патче. */
    fun redFraction(pixels: IntArray): Float {
        if (pixels.isEmpty()) return 0f
        var hits = 0
        for (p in pixels) if (isAlertRed(p)) hits++
        return hits.toFloat() / pixels.size
    }

    /**
     * Знак [!] появился, если красного стало заметно больше, чем было в «спокойном» состоянии.
     * Так красные крыши и кнопки рядом не дают ложных срабатываний.
     */
    fun isAlert(fraction: Float, baseline: Float): Boolean =
        fraction >= 0.20f && (fraction - baseline) >= 0.20f
}
