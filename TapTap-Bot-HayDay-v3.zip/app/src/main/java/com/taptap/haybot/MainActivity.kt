package com.taptap.haybot

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.taptap.haybot.service.TapTapAccessibilityService
import com.taptap.haybot.ui.BgDarkGlass
import com.taptap.haybot.ui.BorderCyanToPink
import com.taptap.haybot.ui.NeonCyan
import com.taptap.haybot.ui.NeonCyanDark
import com.taptap.haybot.ui.NeonGreen
import com.taptap.haybot.ui.NeonPinkRed
import com.taptap.haybot.ui.TextPrimary
import com.taptap.haybot.ui.TextSecondary

class MainActivity : ComponentActivity() {

    private var serviceEnabled by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        serviceEnabled = isServiceEnabled()
        setContent {
            MainScreen(
                serviceEnabled = serviceEnabled,
                onOpenSettings = {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        serviceEnabled = isServiceEnabled()
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = ComponentName(this, TapTapAccessibilityService::class.java)
        return enabled.split(':')
            .mapNotNull { ComponentName.unflattenFromString(it) }
            .any { it == me }
    }
}

@Composable
private fun MainScreen(serviceEnabled: Boolean, onOpenSettings: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDarkGlass)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(24.dp))
                .border(1.5.dp, BorderCyanToPink, RoundedCornerShape(24.dp))
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("TapTap Bot", color = NeonCyan, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                text = if (serviceEnabled) "✅ Служба специальных возможностей включена"
                else "⚠ Служба выключена",
                color = if (serviceEnabled) NeonGreen else NeonPinkRed,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = "1. Включите «TapTap Bot» в Специальных возможностях.\n" +
                        "2. Откройте Hay Day — появится плавающая панель.\n" +
                        "3. «⚙ Настроить» → перетащите прицелы на объекты игры → «✓ Готово».\n" +
                        "4. «▶ Старт».",
                color = TextSecondary,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(22.dp))
                    .background(NeonCyanDark)
                    .border(1.dp, NeonCyan, RoundedCornerShape(22.dp))
                    .clickable { onOpenSettings() }
                    .padding(horizontal = 24.dp, vertical = 12.dp)
            ) {
                Text("Открыть настройки доступности", color = TextPrimary, fontWeight = FontWeight.Bold)
            }
        }
    }
}
