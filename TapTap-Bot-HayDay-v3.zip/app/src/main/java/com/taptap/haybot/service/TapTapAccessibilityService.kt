package com.taptap.haybot.service

import android.accessibilityservice.AccessibilityService
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.HardwareBuffer
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.*
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.taptap.haybot.engine.FarmStateMachine
import com.taptap.haybot.engine.GestureController
import com.taptap.haybot.model.BotRuntimeState
import com.taptap.haybot.model.OverlayUiState
import com.taptap.haybot.ui.TapTapOverlayRoot
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.math.roundToInt

class TapTapAccessibilityService : AccessibilityService(),
    LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: ComposeView
    private lateinit var overlayParams: WindowManager.LayoutParams

    private lateinit var botState: BotRuntimeState
    private var stateMachine: FarmStateMachine? = null

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val screenshotExecutor = Executors.newSingleThreadExecutor()

    private var lifecycleStarted = false
    private var inCalibration = false
    private var savedPillX = 0
    private var savedPillY = 0

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Сервис могут переподключить — второй раз всё не создаём.
        if (lifecycleStarted) return
        lifecycleStarted = true

        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        botState = BotRuntimeState(this)
        updateScreenSize()

        stateMachine = FarmStateMachine(
            state = botState,
            gestures = GestureController(this),
            patchReader = { fx, fy, radius -> readScreenPatch(fx, fy, radius) }
        )

        setupFloatingOverlay()
    }

    private fun updateScreenSize() {
        val m = resources.displayMetrics
        botState.updateScreen(m.widthPixels, m.heightPixels)
    }

    private fun setupFloatingOverlay() {
        overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 180
            y = 40
        }

        overlayView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@TapTapAccessibilityService)
            setViewTreeViewModelStoreOwner(this@TapTapAccessibilityService)
            setViewTreeSavedStateRegistryOwner(this@TapTapAccessibilityService)

            setContent {
                LaunchedEffect(botState.uiState) {
                    applyOverlayMode(botState.uiState == OverlayUiState.CALIBRATION)
                }

                TapTapOverlayRoot(
                    botState = botState,
                    onStartStopClick = { toggleBot() },
                    onMoveOverlayWindow = { dx, dy ->
                        if (botState.uiState != OverlayUiState.CALIBRATION) {
                            overlayParams.x += dx.roundToInt()
                            overlayParams.y += dy.roundToInt()
                            runCatching { windowManager.updateViewLayout(overlayView, overlayParams) }
                        }
                    }
                )
            }
        }

        windowManager.addView(overlayView, overlayParams)
    }

    /** Калибровка — на весь экран с нулевым смещением, чтобы координаты совпадали с экранными. */
    private fun applyOverlayMode(calibration: Boolean) {
        if (calibration) {
            if (!inCalibration) {
                savedPillX = overlayParams.x
                savedPillY = overlayParams.y
            }
            inCalibration = true
            overlayParams.x = 0
            overlayParams.y = 0
            overlayParams.width = WindowManager.LayoutParams.MATCH_PARENT
            overlayParams.height = WindowManager.LayoutParams.MATCH_PARENT
        } else {
            if (inCalibration) {
                overlayParams.x = savedPillX
                overlayParams.y = savedPillY
            }
            inCalibration = false
            overlayParams.width = WindowManager.LayoutParams.WRAP_CONTENT
            overlayParams.height = WindowManager.LayoutParams.WRAP_CONTENT
        }
        runCatching { windowManager.updateViewLayout(overlayView, overlayParams) }
    }

    private fun toggleBot() {
        val machine = stateMachine ?: return
        if (botState.isRunning) machine.stop() else machine.start()
    }

    /**
     * Читает квадрат пикселей вокруг точки (fx, fy — доли экрана).
     * Вместо одного пикселя берём патч, чтобы не ловить случайный шум.
     * Возвращает null, если скриншот не удался (лимит частоты, нет права и т.д.).
     */
    private suspend fun readScreenPatch(fx: Float, fy: Float, radius: Int): IntArray? =
        suspendCancellableCoroutine { cont ->
            try {
                takeScreenshot(
                    Display.DEFAULT_DISPLAY,
                    screenshotExecutor,
                    object : AccessibilityService.TakeScreenshotCallback {
                        override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                            var result: IntArray? = null
                            var buffer: HardwareBuffer? = null
                            try {
                                val hw = screenshot.hardwareBuffer
                                buffer = hw
                                val hwBitmap = Bitmap.wrapHardwareBuffer(hw, screenshot.colorSpace)
                                val soft = hwBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                                hwBitmap?.recycle()
                                if (soft != null) {
                                    val size = radius * 2 + 1
                                    val cx = (fx * soft.width).roundToInt()
                                        .coerceIn(radius, soft.width - radius - 1)
                                    val cy = (fy * soft.height).roundToInt()
                                        .coerceIn(radius, soft.height - radius - 1)
                                    val pixels = IntArray(size * size)
                                    soft.getPixels(pixels, 0, size, cx - radius, cy - radius, size, size)
                                    soft.recycle()
                                    result = pixels
                                }
                            } catch (e: Exception) {
                                result = null
                            } finally {
                                try {
                                    buffer?.close()
                                } catch (e: Exception) {
                                    // уже закрыт
                                }
                            }
                            if (cont.isActive) cont.resume(result)
                        }

                        override fun onFailure(errorCode: Int) {
                            if (cont.isActive) cont.resume(null)
                        }
                    }
                )
            } catch (e: Exception) {
                if (cont.isActive) cont.resume(null)
            }
        }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!::botState.isInitialized || !botState.isRunning) return

        val pkg = event.packageName?.toString() ?: return
        if (pkg == HAY_DAY_PACKAGE || pkg == packageName || pkg in IGNORED_PACKAGES) return

        // Игра свернута / открылось другое приложение — не кликаем вслепую.
        stateMachine?.stop("Игра свернута ($pkg) — бот остановлен")
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::botState.isInitialized) updateScreenSize()
    }

    override fun onInterrupt() {
        stateMachine?.stop()
    }

    override fun onDestroy() {
        stateMachine?.release()
        stateMachine = null
        if (::overlayView.isInitialized) {
            runCatching { overlayView.disposeComposition() }
            runCatching { windowManager.removeView(overlayView) }
        }
        if (lifecycleStarted) {
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        }
        screenshotExecutor.shutdown()
        super.onDestroy()
    }

    private companion object {
        const val HAY_DAY_PACKAGE = "com.supercell.hayday"
        val IGNORED_PACKAGES = setOf("com.android.systemui", "android")
    }
}
