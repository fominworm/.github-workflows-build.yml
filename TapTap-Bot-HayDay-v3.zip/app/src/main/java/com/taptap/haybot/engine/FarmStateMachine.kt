package com.taptap.haybot.engine

import android.graphics.PointF
import com.taptap.haybot.model.BotPhase
import com.taptap.haybot.model.BotRuntimeState
import com.taptap.haybot.model.PinId
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.min

/**
 * Конечный автомат фермы: аудит силоса → сбор → посев → киоск → ожидание/охота на [!].
 *
 * [patchReader] читает квадрат пикселей вокруг точки экрана (в ДОЛЯХ экрана), радиус в пикселях.
 */
class FarmStateMachine(
    private val state: BotRuntimeState,
    private val gestures: GestureController,
    private val patchReader: suspend (Float, Float, Int) -> IntArray?
) {
    private var engineJob: Job? = null
    private var timersJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var failStreak = 0
    private var shopVisitsWithoutHarvest = 0
    private var lastHarvestRows = 0

    fun start() {
        if (state.isRunning) return
        state.isRunning = true
        state.currentPhase = BotPhase.IDLE
        state.statusLog = "Запуск цикла TapTap Bot..."
        failStreak = 0
        shopVisitsWithoutHarvest = 0
        lastHarvestRows = 0
        state.refreshTimers()

        timersJob?.cancel()
        timersJob = scope.launch {
            while (isActive && state.isRunning) {
                delay(1000L)
                state.uptimeSeconds++
                state.refreshTimers()
            }
        }

        engineJob?.cancel()
        engineJob = scope.launch {
            try {
                while (isActive && state.isRunning) {
                    runSingleStep()
                    delay(STEP_DELAY_MS)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                stop("Ошибка: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun stop(message: String = "Бот остановлен пользователем") {
        state.isRunning = false
        state.currentPhase = BotPhase.IDLE
        state.statusLog = message
        state.saveSettings()
        engineJob?.cancel()
        timersJob?.cancel()
    }

    /** Полное освобождение ресурсов при выключении сервиса. */
    fun release() {
        stop("Сервис выключен")
        scope.cancel()
    }

    // ------------------------------------------------------------------ шаги

    private suspend fun runSingleStep() {
        when (state.currentPhase) {
            BotPhase.IDLE, BotPhase.CHECK_CAPACITY -> stepCheckCapacity()
            BotPhase.HARVEST -> stepHarvest()
            BotPhase.PLANT -> stepPlant()
            BotPhase.LOAD_SHOP -> stepLoadShop()
            BotPhase.CAMP_ALERT -> stepCampAlert()
            BotPhase.HOT_SWAP -> stepHotSwap()
            BotPhase.WAIT_GROWTH -> stepWaitGrowth()
        }
    }

    private fun stepCheckCapacity() {
        state.currentPhase = BotPhase.CHECK_CAPACITY
        state.refreshTimers()

        if (state.maturityRemainingSec > 0) {
            state.currentPhase =
                if (state.hotSwapEnabled && state.availableStacksToSell > 0) BotPhase.CAMP_ALERT
                else BotPhase.WAIT_GROWTH
            return
        }

        when {
            state.canFullHarvestSafely -> state.currentPhase = BotPhase.HARVEST

            // Сначала освобождаем место продажей, но не ходим в киоск по кругу.
            state.availableStacksToSell > 0 && shopVisitsWithoutHarvest < MAX_SHOP_VISITS -> {
                shopVisitsWithoutHarvest++
                state.statusLog = "Силос: ${state.siloCurrent}/${state.siloCapacity}. Разгрузка через киоск..."
                state.currentPhase = BotPhase.LOAD_SHOP
            }

            state.safeHarvestFields > 0 -> {
                state.statusLog = "Частичный сбор: места хватает на ${state.safeHarvestFields} грядок"
                state.currentPhase = BotPhase.HARVEST
            }

            else -> stop(
                "Силос полон, продавать нечего. Поправьте счётчики силоса/пшеницы в панели и запустите снова"
            )
        }
    }

    private suspend fun stepHarvest() {
        val fields = state.safeHarvestFields
        if (fields <= 0) {
            state.currentPhase = BotPhase.CHECK_CAPACITY
            return
        }

        val perRow = BotLogic.fieldsPerRow(state.fieldCount, state.fieldRows)
        val rows = BotLogic.rowsToCover(fields, perRow, state.fieldRows)
        state.statusLog = "Сбор поля: $fields грядок ($rows из ${state.fieldRows} рядов)..."

        if (!runFieldAction(PinId.TOOL_SICKLE, rows)) return

        val harvested = min(rows * perRow, state.fieldCount)
        val gained = min(harvested * BotLogic.WHEAT_YIELD, state.freeSiloSpace)
        state.siloCurrent = min(state.siloCapacity, state.siloCurrent + gained)
        state.wheatCurrent += gained
        state.saveSettings()

        lastHarvestRows = rows
        shopVisitsWithoutHarvest = 0
        state.currentPhase = BotPhase.PLANT
    }

    private suspend fun stepPlant() {
        val perRow = BotLogic.fieldsPerRow(state.fieldCount, state.fieldRows)
        val rows = lastHarvestRows.coerceIn(1, state.fieldRows.coerceAtLeast(1))
        val toPlant = min(min(rows * perRow, state.fieldCount), state.wheatCurrent)

        if (toPlant <= 0) {
            stop("Нет пшеницы для посева. Поправьте счётчик пшеницы в панели")
            return
        }

        state.statusLog = "Посев: $toPlant грядок ($rows рядов)..."
        if (!runFieldAction(PinId.TOOL_WHEAT, rows)) return

        state.siloCurrent = (state.siloCurrent - toPlant).coerceAtLeast(0)
        state.wheatCurrent = (state.wheatCurrent - toPlant).coerceAtLeast(0)
        state.startGrowth(BotLogic.GROWTH_SEC)

        state.currentPhase =
            if (state.availableStacksToSell > 0) BotPhase.LOAD_SHOP else BotPhase.WAIT_GROWTH
    }

    private suspend fun stepLoadShop() {
        state.statusLog = "Открытие киоска и выкладка товара..."
        if (!tapPin(PinId.SHOP_ALERT, 70L)) {
            registerFailure("Не удалось открыть киоск")
            return
        }
        failStreak = 0
        delay(450L)

        collectSoldSlots()

        val stacksToPut = min(state.availableStacksToSell, state.shopTotalSlots)
        if (stacksToPut > 0) {
            fillShopSlots(
                count = stacksToPut,
                placeAdOnLastSlot = state.adCooldownRemainingSec == 0
            )
        }

        delay(250L)
        tapPin(PinId.DEAD_STOP, 80L)
        delay(300L)

        state.currentPhase =
            if (state.hotSwapEnabled && state.availableStacksToSell > 0) BotPhase.CAMP_ALERT
            else BotPhase.WAIT_GROWTH
    }

    private suspend fun stepCampAlert() {
        state.statusLog = "Охота на [!]: ждём покупателя (резерв семян: ${state.seedReserve})"
        val shopAlert = state.frac(PinId.SHOP_ALERT)

        // «Спокойное» состояние точки — чтобы красные крыши не считались знаком.
        var baseline = 0f
        val first = patchReader(shopAlert.x, shopAlert.y, PATCH_RADIUS)
        if (first != null) baseline = BotLogic.redFraction(first)

        var screenshotFailures = 0
        while (state.isRunning && state.maturityRemainingSec > 5 && state.availableStacksToSell > 0) {
            val patch = patchReader(shopAlert.x, shopAlert.y, PATCH_RADIUS)
            if (patch == null) {
                screenshotFailures++
                if (screenshotFailures >= MAX_SCREENSHOT_FAILURES) {
                    state.hotSwapEnabled = false
                    state.saveSettings()
                    state.statusLog = "Скриншоты недоступны — Hot-Swap выключен, жду роста"
                    state.currentPhase = BotPhase.WAIT_GROWTH
                    return
                }
                delay(SCAN_INTERVAL_MS * 2)
                continue
            }
            screenshotFailures = 0

            if (BotLogic.isAlert(BotLogic.redFraction(patch), baseline)) {
                state.statusLog = "Замечен знак [!] — вход в HOT-SWAP!"
                state.currentPhase = BotPhase.HOT_SWAP
                return
            }
            delay(SCAN_INTERVAL_MS)
        }

        state.currentPhase = BotPhase.WAIT_GROWTH
    }

    private suspend fun stepHotSwap() {
        if (!tapPin(PinId.SHOP_ALERT, 55L)) {
            registerFailure("Не удалось открыть киоск (Hot-Swap)")
            return
        }
        failStreak = 0
        delay(320L)

        for (wave in 1..HOT_SWAP_WAVES) {
            if (!state.isRunning || state.availableStacksToSell <= 0) break
            state.statusLog = "Hot-Swap волна #$wave: сбор монет и докладка..."

            collectSoldSlots()
            val refill = min(state.availableStacksToSell, MAX_REFILL_PER_WAVE)
            fillShopSlots(count = refill, placeAdOnLastSlot = false)
            delay(1200L)
        }

        tapPin(PinId.DEAD_STOP, 80L)
        delay(250L)
        state.currentPhase = BotPhase.CHECK_CAPACITY
    }

    private suspend fun stepWaitGrowth() {
        state.refreshTimers()
        state.statusLog = "Ожидание созревания пшеницы (${state.maturityRemainingSec} с)..."
        if (state.maturityRemainingSec <= 0) {
            state.currentPhase = BotPhase.CHECK_CAPACITY
        } else {
            delay(500L)
        }
    }

    // ------------------------------------------------------------ киоск

    private fun slotPoint(index: Int, slots: Int): PointF {
        val first = state.px(PinId.SHOP_FIRST_SLOT)
        val last = state.px(PinId.SHOP_LAST_SLOT)
        val n = slots.coerceAtLeast(2)
        val stepX = (last.x - first.x) / (n - 1)
        return PointF(first.x + stepX * index, first.y)
    }

    private suspend fun collectSoldSlots() {
        val slots = state.shopTotalSlots.coerceAtLeast(2)
        for (i in 0 until slots) {
            gestures.tap(slotPoint(i, slots), 45L)
            delay(75L)
        }
    }

    private suspend fun fillShopSlots(count: Int, placeAdOnLastSlot: Boolean) {
        val slots = state.shopTotalSlots.coerceAtLeast(2)

        for (i in 0 until count) {
            if (!state.isRunning || state.availableStacksToSell <= 0) break

            val isLastInBatch = i == count - 1
            val useAd = isLastInBatch && placeAdOnLastSlot
            val target = if (useAd) state.px(PinId.SHOP_LAST_SLOT) else slotPoint(i, slots)

            gestures.tap(target, 55L)
            delay(180L)

            tapPin(PinId.SHOP_ITEM, 55L)
            delay(140L)

            setPrice(BotLogic.resolvePrice(
                state.priceStrategy, state.freeSiloSpace, state.fieldCount, slots - i
            ))

            if (useAd) {
                tapPin(PinId.AD_CHECKBOX, 55L)
                delay(110L)
                state.startAdCooldown(BotLogic.AD_COOLDOWN_SEC)
            }

            tapPin(PinId.CONFIRM_PUT, 60L)
            delay(180L)

            state.siloCurrent = (state.siloCurrent - BotLogic.STACK_SIZE).coerceAtLeast(0)
            state.wheatCurrent = (state.wheatCurrent - BotLogic.STACK_SIZE).coerceAtLeast(0)
        }
        state.saveSettings()
    }

    /** «Макс. цена», затем нужное число нажатий «−». */
    private suspend fun setPrice(price: Int) {
        tapPin(PinId.PRICE_MAX, 45L)
        delay(90L)
        repeat(BotLogic.priceMinusTaps(price)) {
            tapPin(PinId.PRICE_MINUS, 35L)
            delay(45L)
        }
    }

    // ------------------------------------------------------------ утилиты

    private suspend fun tapPin(id: PinId, holdMs: Long): Boolean =
        gestures.tap(state.px(id), holdMs)

    private suspend fun runFieldAction(tool: PinId, rows: Int): Boolean {
        val ok = gestures.executeFieldAction(
            anchor = state.px(PinId.ANCHOR_FIELD),
            tool = state.px(tool),
            fieldEnd = state.px(PinId.FIELD_END),
            deadStop = state.px(PinId.DEAD_STOP),
            rowsTotal = state.fieldRows,
            rowsToCover = rows,
            swipeDurationMs = state.swipeDurationMs,
            useDeadStop = state.deadStopEnabled
        )
        if (ok) {
            failStreak = 0
        } else {
            registerFailure("Жест не выполнен")
        }
        return ok
    }

    /** true — можно пробовать ещё; false — бот остановлен из-за серии сбоев. */
    private suspend fun registerFailure(reason: String): Boolean {
        failStreak++
        state.statusLog = "$reason ($failStreak/$MAX_FAILS)"
        if (failStreak >= MAX_FAILS) {
            stop("$reason $MAX_FAILS раза подряд — бот остановлен")
            return false
        }
        delay(500L)
        return true
    }

    private companion object {
        const val STEP_DELAY_MS = 250L
        const val SCAN_INTERVAL_MS = 450L        // скриншоты лимитируются системой (~0.3 с)
        const val PATCH_RADIUS = 6
        const val MAX_FAILS = 3
        const val MAX_SHOP_VISITS = 2
        const val MAX_SCREENSHOT_FAILURES = 15
        const val HOT_SWAP_WAVES = 3
        const val MAX_REFILL_PER_WAVE = 4
    }
}
