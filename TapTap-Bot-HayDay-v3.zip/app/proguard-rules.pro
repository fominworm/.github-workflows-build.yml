# TapTap Bot ProGuard rules
-keep class com.taptap.haybot.** { *; }
